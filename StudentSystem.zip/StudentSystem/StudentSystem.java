package StudentSystem;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class StudentSystem {
    public static void main(String[] args) {
        ArrayList<Student> list = new ArrayList<>();
        ArrayList<User> list2 = new ArrayList<>();

        loop:
        while (true) {
            Scanner sc = new Scanner(System.in);
            System.out.println("欢迎来到学生管理系统");
            System.out.println("请选择操作1:登录 2:注册 3:忘记密码");

            String choose = sc.next();

            switch (choose) {
                case "1" -> {
                    if (logIn(list2)) {
                        break loop;
                    }
                }
                case "2" -> signIn(list2);
                case "3" -> forgotPassword(list2);
            }
        }


        loop:
        while (true) {
            Scanner sc = new Scanner(System.in);
            System.out.println("-------------欢迎来到黑马学生管理系统----------------");
            System.out.println("1：添加学生");
            System.out.println("2：删除学生");
            System.out.println("3：修改学生");
            System.out.println("4：查询学生");
            System.out.println("5：退出");
            System.out.println("请输入您的选择:");

            String choose = sc.next(); //输入想要进行操作的编号

            switch (choose) {  //添加学生信息
                case "1" -> addStudent(list);  //输入1，进入添加学生操作
                case "2" -> deleteStudent(list);  //输入2，进入删除学生操作
                case "3" -> updateStudent(list);  //输入3，进入修改学生操作
                case "4" -> queryStudent(list);  //输入4，进入查询学生操作
                case "5" -> {
                    System.out.println("退出"); //输入5，退出学生管理系统
                    break loop;
                }
                default -> System.out.println("没有这个选项");  //错误输入，提示没有这个选项
            }
        }
    }

    //添加学生信息的方法
    public static void addStudent(ArrayList<Student> list) {
        Student student = new Student();

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("请输入学生的ID");
            String id = sc.next();
            boolean flag = contains(list, id);
            if (!flag) {  //若数组中没有这个ID，就创建这个ID
                student.setId(id);
                break;
            } else {
                System.out.println("学生ID重复，请重新添加");
            }
        }

        System.out.println("请输入学生的姓名");
        String name = sc.next();
        student.setName(name);

        System.out.println("请输入学生的年龄");
        int age = sc.nextInt();
        student.setAge(age);

        System.out.println("请输入学生的住址");
        String address = sc.next();
        student.setAddress(address);

        list.add(student);

        System.out.println("学生信息添加成功");

    }

    //删除学生信息的方法
    public static void deleteStudent(ArrayList<Student> list) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入要删除的ID");
        String id = sc.next();
        int index = getIndex(list, id);  //获取需要删除ID在集合中的索引
        if (index >= 0) {  //若数组中有这个ID，就进行删除操作，没有就输出ID不存在
            list.remove(index);  //删除集合中index索引位置的数据
        } else {
            System.out.println("需要删除的ID不存在");
        }
    }

    //修改学生信息的方法
    public static void updateStudent(ArrayList<Student> list) {
        Scanner sc = new Scanner(System.in);
        Student student = new Student();
        System.out.println("请输入想要修改的ID");
        String id = sc.next();
        int index = getIndex(list, id); //获取需要修改ID在集合中的索引
        if (index >= 0) { //若ID存在，则创建出新的学生对象数据
            student.setId(id);

            System.out.println("请输入想要修改的名称");
            String name = sc.next();
            student.setName(name);

            System.out.println("请输入想要修改的年龄");
            int age = sc.nextInt();
            student.setAge(age);

            System.out.println("请输入想要修改的地址");
            String address = sc.next();
            student.setAddress(address);

            list.set(index, student);  //将新创建的学生对象数据，对index索引中的数据进行覆盖
        } else {
            System.out.println("需要修改的ID不存在");
        }
    }

    //查询学生信息的方法
    public static void queryStudent(ArrayList<Student> list) {
        if (list.isEmpty()) {  //如果集合为空，提醒添加数据
            System.out.println("当前无学生信息，请添加后再查询");
            return;
        }

        //输出集合中的所有数据
        System.out.println("id\t\t姓名\t年龄\t家庭住址");
        for (int i = 0; i < list.size(); i++) {
            Student student = list.get(i);
            System.out.println(student.getId() + "\t" + student.getName() + "\t" + student.getAge() + " " + student.getAddress());
        }
    }

    //检测是否存在ID的方法
    public static boolean contains(ArrayList<Student> list, String id) {
        return getIndex(list, id) >= 0;  //若集合中有ID相同，则必然大于等于0，返回true。反则为否。
    }

    //寻找指定ID在集合中索引的方法
    public static int getIndex(ArrayList<Student> list, String id) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(id)) {  //若指定ID与集合中的ID有相等，返回集合索引值i
                return i;
            }
        }
        return -1;  //否则返回-1
    }

    //用户注册方法
    public static void signIn(ArrayList<User> list2) {
        User user = new User();
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("请输入你注册的用户名");
            String username = sc.next();
            boolean flag = contains2(list2, username);
            if (!flag) {
                boolean rightUserName = checkUser(username);
                if (rightUserName) {
                    user.setUsername(username);
                    break;
                }
            } else {
                System.out.println("用户名重复，请重新输入");
            }
        }

        System.out.println("请输入你注册的密码");
        String password = sc.next();
        while (true) {
            System.out.println("请再次输入你的密码");
            String checkPassword = sc.next();
            if (checkPassword.equals(password)) {
                user.setPassword(checkPassword);
                break;
            } else {
                System.out.println("密码不一致，请重新输入");
            }
        }

        while (true) {
            System.out.println("请输入你的身份证号");
            String userId = sc.next();
            boolean flag = checkUserId(userId);
            if (flag) {
                user.setUserId(userId);
                break;
            }
        }

        while (true) {
            System.out.println("请输入你的手机号码");
            String phoneNumber = sc.next();
            boolean flag = checkPhoneNumber(phoneNumber);
            if (flag) {
                user.setPhoneNumber(phoneNumber);
                break;
            }
        }

        list2.add(user);
    }

    //用户登录方法
    public static boolean logIn(ArrayList<User> list2) { //登录程序
        if (list2.isEmpty()) {
            System.out.println("用户名未注册，请先注册");
        } else {
            Scanner sc = new Scanner(System.in);
            int count = 3;
            while (true) {
                System.out.println("请输入用户名");
                String username = sc.next();
                System.out.println("请输入密码");
                String password = sc.next();
                while (true) {
                    String captcha = captcha();
                    System.out.println("请输入验证码" + captcha);
                    String checkCaptcha = sc.next();
                    if (checkCaptcha.equals(captcha)) {
                        break;
                    } else {
                        System.out.println("验证码输入错误，请重新输入");
                    }
                }
                boolean flag = contains2(list2, username);
                if (flag) {
                    int usernameIndex = getIndex2(list2, username);
                    if (list2.get(usernameIndex).getPassword().equals(password)) {
                        return true;
                    } else {
                        count--;
                        System.out.println("密码输入错误，还有" + count + "次机会");
                    }
                } else {
                    count--;
                    System.out.println("用户名输入错误，还有" + count + "次机会");
                }
                if (count == 0) {
                    System.out.println("登录失败，请重新登录");
                    break;
                }
            }
        }
        return false;
    }

    //用户忘记密码方法
    public static void forgotPassword(ArrayList<User> list2) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入用户名");
        String username = sc.next();
        boolean flag = contains2(list2, username);
        if (flag) {
            int index = getIndex2(list2, username);
            System.out.println("请输入身份证号码");
            String userId = sc.next();
            System.out.println("请输入手机号码");
            String phoneNumber = sc.next();
            if (list2.get(index).getUserId().equals(userId) && list2.get(index).getPhoneNumber().equals(phoneNumber)) {
                System.out.println("请输入你要修改的密码");
                String newPassword = sc.next();
                list2.get(index).setPassword(newPassword);
            } else {
                System.out.println("账号信息不匹配，修改失败");
            }
        } else {
            System.out.println("未注册");
        }
    }

    //检测用户名是否符合要求的方法
    public static boolean checkUser(String username) {
        int count = 0;
        if (username.length() >= 3 && username.length() <= 15) {
            char[] arr = username.toCharArray();
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] >= 'A' && arr[i] <= 'Z' || arr[i] >= 'a' && arr[i] <= 'z') {
                    count++;
                    break;
                }
            }
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] >= '0' && arr[i] <= '9') {
                    count++;
                    break;
                }
            }
            if (count == 2) {
                return true;
            } else {
                System.out.println("用户名必须包括数字和字母，请重新输入");
            }
        } else {
            System.out.println("用户名必须在3-15字符以内，请重新输入");
        }
        return false;
    }

    //检测用户名是否存在的方法
    public static boolean contains2(ArrayList<User> list2, String username) {
        return getIndex2(list2, username) >= 0;  //若集合中有ID相同，则必然大于等于0，返回true。反则为否。
    }

    //寻找指定用户名在集合中索引的方法
    public static int getIndex2(ArrayList<User> list2, String username) {
        for (int i = 0; i < list2.size(); i++) {
            if (list2.get(i).getUsername().equals(username)) {  //若指定ID与集合中的ID有相等，返回集合索引值i
                return i;
            }
        }
        return -1;  //否则返回-1
    }

    //检测身份证是否符合要求的方法
    public static boolean checkUserId(String userId) {
        char[] arr = userId.toCharArray();
        int count = 0;
        if (arr.length == 18) {
            if (arr[0] != '0') {
                for (int i = 0; i < arr.length - 1; i++) {
                    if (arr[i] >= '0' && arr[i] <= '9') {
                        count++;
                    }
                }
                if (arr[arr.length - 1] >= '0' && arr[arr.length - 1] <= '9' || arr[arr.length - 1] == 'X' || arr[arr.length - 1] == 'x') {
                    count++;
                }
                if (count == 18) {
                    return true;
                } else {
                    System.out.println("身份证格式错误，请重新输入");
                }
            } else {
                System.out.println("身份证号码开头不能为0");
            }
        } else {
            System.out.println("身份证号码必须为18位，请重新输入");
        }
        return false;
    }

    //检测手机号是否符合要求的方法
    public static boolean checkPhoneNumber(String phoneNumber) {
        int count = 0;
        char[] arr = phoneNumber.toCharArray();
        if (arr.length == 11) {
            if (arr[arr.length - 1] != '0') {
                for (int i = 0; i < arr.length; i++) {
                    if (arr[i] >= '0' && arr[i] <= '9') {
                        count++;
                    } else {
                        System.out.println("手机号码必须全部是数字");
                        break;
                    }
                }
                if (count == 11) {
                    return true;
                }
            } else {
                System.out.println("手机号码第一位不能为0");
            }
        } else {
            System.out.println("手机号必须是11位，请重新输入");
        }
        return false;
    }

    //生成验证码的方法
    public static String captcha() {
        Random r = new Random();
        char[] arr = new char[36];

        //将大写字母加入到字符数组
        for (int i = 0; i < 26; i++) {
            arr[i] = (char) ('A' + i);
        }
        //将数字加入到字符数组
        for (int i = 0; i < 10; i++) {
            arr[26 + i] = (char) ('0' + i);
        }

        char[] captchaArr = new char[5];
        for (int i = 0; i < captchaArr.length; i++) {
            int randomIndex = r.nextInt(36);
            captchaArr[i] = arr[randomIndex];
        }

        String captcha = "";
        for (int i = 0; i < captchaArr.length; i++) {
            captcha += captchaArr[i];
        }

        return captcha;
    }
}